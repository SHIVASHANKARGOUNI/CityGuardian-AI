package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.CityGuardianDao
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        ComplaintEntity::class,
        DepartmentEntity::class,
        WorkerEntity::class,
        NotificationEntity::class,
        CityWardEntity::class,
        PredictiveMaintenanceEntity::class,
        AIReportEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CityGuardianDatabase : RoomDatabase() {

    abstract fun cityGuardianDao(): CityGuardianDao

    companion object {
        @Volatile
        private var INSTANCE: CityGuardianDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): CityGuardianDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CityGuardianDatabase::class.java,
                    "city_guardian_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.cityGuardianDao())
                }
            }
        }

        suspend fun populateInitialData(dao: CityGuardianDao) {
            // Initial Users
            val citizenRahul = UserEntity("c_rahul", "Rahul Verma", "rahul.citizen@metrocity.gov", UserRole.CITIZEN, phone = "+1 (555) 019-2834")
            val workerRavi = UserEntity("w_ravi", "Ravi Kumar", "ravi.worker@metrocity.gov", UserRole.WORKER, department = "Sanitation & Waste", phone = "+1 (555) 392-1021")
            val adminPriya = UserEntity("a_priya", "Priya Sharma", "priya.officer@metrocity.gov", UserRole.ADMIN, department = "Municipal Administration", phone = "+1 (555) 800-4012")

            val citizen1 = UserEntity("c1", "Alex Rivera", "alex.rivera@citizen.gov", UserRole.CITIZEN)
            val worker1 = UserEntity("w1", "Marcus Vance", "marcus.vance@city.gov", UserRole.WORKER, "Sanitation & Waste")
            val worker2 = UserEntity("w2", "Elena Rostova", "elena.rostova@city.gov", UserRole.WORKER, "Public Works & Roads")
            val admin1 = UserEntity("a1", "Mayor Victoria Sterling", "mayor.office@metrocity.gov", UserRole.ADMIN)

            dao.insertUser(citizenRahul)
            dao.insertUser(workerRavi)
            dao.insertUser(adminPriya)
            dao.insertUser(citizen1)
            dao.insertUser(worker1)
            dao.insertUser(worker2)
            dao.insertUser(admin1)

            // Departments
            val departments = listOf(
                DepartmentEntity("dept_san", "Sanitation & Waste", "delete", "Chief Sarah Jenkins", 14, 28),
                DepartmentEntity("dept_pw", "Public Works & Roads", "construction", "Director Robert Vance", 22, 35),
                DepartmentEntity("dept_elec", "Electrical & Grid", "bolt", "Eng. Michael Thorne", 8, 19),
                DepartmentEntity("dept_water", "Water & Sewage", "water_drop", "Director Linda Martinez", 11, 24),
                DepartmentEntity("dept_traffic", "Traffic & Transit", "traffic", "Capt. James Mercer", 6, 15)
            )
            dao.insertDepartments(departments)

            // Workers
            val workers = listOf(
                WorkerEntity("w1", "Marcus Vance", "Sanitation & Waste", "+1 (555) 392-1021", "On-Site", 142, 4.9f),
                WorkerEntity("w2", "Elena Rostova", "Public Works & Roads", "+1 (555) 481-9023", "Available", 98, 4.8f),
                WorkerEntity("w3", "David Chen", "Electrical & Grid", "+1 (555) 892-3019", "On-Site", 115, 4.95f),
                WorkerEntity("w4", "Carlos Mendez", "Water & Sewage", "+1 (555) 201-8472", "Available", 84, 4.7f),
                WorkerEntity("w5", "Priya Sharma", "Traffic & Transit", "+1 (555) 912-4018", "Available", 67, 4.85f)
            )
            dao.insertWorkers(workers)

            // City Wards Health Scores
            val wardScores = listOf(
                CityWardEntity("ward_1", "Ward 1 - Downtown Core", 88, 85, 90, 88, 92, 98, 4),
                CityWardEntity("ward_2", "Ward 2 - Innovation District", 92, 94, 91, 95, 89, 99, 2),
                CityWardEntity("ward_3", "Ward 3 - Metro South", 64, 58, 62, 60, 71, 82, 14),
                CityWardEntity("ward_4", "Ward 4 - Riverside Commons", 79, 82, 75, 80, 76, 91, 7),
                CityWardEntity("ward_5", "Ward 5 - Industrial Hub", 51, 45, 48, 52, 54, 75, 23),
                CityWardEntity("ward_6", "Ward 6 - Green Valley Heights", 95, 96, 94, 97, 98, 100, 1)
            )
            dao.insertWardScores(wardScores)

            // Seed Complaints
            val now = System.currentTimeMillis()
            val day = 86400000L

            val c1 = ComplaintEntity(
                title = "Hazardous Deep Pothole on 5th Avenue",
                description = "Severe crater-like pothole near the bus stop causing vehicle tire blowouts and traffic hazard.",
                category = "Potholes",
                severity = "Critical",
                priority = "P1",
                status = "In Progress",
                citizenId = "c1",
                citizenName = "Alex Rivera",
                wardName = "Ward 3 - Metro South",
                latitude = 37.7749,
                longitude = -122.4194,
                address = "742 5th Avenue, Metro South",
                imageUri = "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600",
                beforeImageUri = "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600",
                voiceText = "There is a huge pothole right in front of the bus station on 5th Avenue. Cars are swerving into oncoming traffic!",
                aiReasoning = "Gemma Severity Classification: Critical (P1). High traffic artery risk, potential multi-vehicle collision hazard.",
                detectedObjects = "Pothole (96.4%), Asphalt Fatigue (88.2%), Road Hazard (92.1%)",
                department = "Public Works & Roads",
                assignedWorkerId = "w2",
                assignedWorkerName = "Elena Rostova",
                estimatedHours = 12,
                createdAt = now - (0.8 * day).toLong()
            )

            val c2 = ComplaintEntity(
                title = "Overflowing Commercial Trash Container",
                description = "Garbage bin overflowing onto sidewalk creating sanitation concern and blocking pedestrian walkway.",
                category = "Garbage",
                severity = "High",
                priority = "P2",
                status = "Assigned",
                citizenId = "c1",
                citizenName = "Alex Rivera",
                wardName = "Ward 5 - Industrial Hub",
                latitude = 37.7833,
                longitude = -122.4167,
                address = "1208 Industrial Way, Ward 5",
                imageUri = "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=600",
                voiceText = "Trash containers near building B are completely overflowing and smelling bad.",
                aiReasoning = "Gemma Severity Classification: High (P2). Health code violation threat in dense zone.",
                detectedObjects = "Overflowing Trash (98.1%), Waste Container (94.5%)",
                department = "Sanitation & Waste",
                assignedWorkerId = "w1",
                assignedWorkerName = "Marcus Vance",
                estimatedHours = 6,
                createdAt = now - (1.2 * day).toLong()
            )

            val c3 = ComplaintEntity(
                title = "Broken Substation Streetlight Grid",
                description = "Entire row of 6 streetlights dead along Oak Street causing complete dark zone at night.",
                category = "Broken Streetlights",
                severity = "Critical",
                priority = "P1",
                status = "Resolved",
                citizenId = "c1",
                citizenName = "Alex Rivera",
                wardName = "Ward 1 - Downtown Core",
                latitude = 37.7695,
                longitude = -122.4467,
                address = "300 Oak Street, Downtown",
                imageUri = "https://images.unsplash.com/photo-1509114397022-ed747cca3f65?w=600",
                beforeImageUri = "https://images.unsplash.com/photo-1509114397022-ed747cca3f65?w=600",
                afterImageUri = "https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=600",
                voiceText = "Oak Street is pitch black at night, all six street lamps went out together.",
                aiReasoning = "Gemma Severity Classification: Critical (P1). Night public safety risk and transformer grid issue.",
                detectedObjects = "Dark Luminaires (91.0%), Power Substation Line (87.5%)",
                department = "Electrical & Grid",
                assignedWorkerId = "w3",
                assignedWorkerName = "David Chen",
                estimatedHours = 4,
                createdAt = now - (3.5 * day).toLong(),
                resolvedAt = now - (0.5 * day).toLong(),
                resolutionNotes = "Replaced master circuit breaker and LED lamp modules. Grid fully illuminated."
            )

            val c4 = ComplaintEntity(
                title = "High Pressure Water Main Leak",
                description = "Clean water leaking onto asphalt pavement at approximately 15 gallons per minute.",
                category = "Water Leakage",
                severity = "High",
                priority = "P2",
                status = "Submitted",
                citizenId = "c1",
                citizenName = "Alex Rivera",
                wardName = "Ward 3 - Metro South",
                latitude = 37.7550,
                longitude = -122.4200,
                address = "89 Pine Street, Metro South",
                imageUri = "https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3?w=600",
                aiReasoning = "Gemma Severity Classification: High (P2). Municipal water waste and road sub-base erosion risk.",
                detectedObjects = "Pressurized Water Stream (95.0%), Asphalt Erosion (89.0%)",
                department = "Water & Sewage",
                createdAt = now - (0.2 * day).toLong()
            )

            dao.insertComplaint(c1)
            dao.insertComplaint(c2)
            dao.insertComplaint(c3)
            dao.insertComplaint(c4)

            // Predictive Maintenance Seed
            val predictiveList = listOf(
                PredictiveMaintenanceEntity(
                    wardName = "Ward 5 - Industrial Hub",
                    issueType = "Garbage Overflow Risk",
                    riskLevel = "Critical",
                    predictionSummary = "Gemma predictive algorithm forecasts a 94% probability of major waste overflow in Industrial Way over the upcoming weekend due to scheduled factory shift closures.",
                    recommendationAction = "Deploy 2 additional Sanitation Compactor Units proactively on Friday evening."
                ),
                PredictiveMaintenanceEntity(
                    wardName = "Ward 3 - Metro South",
                    issueType = "Road Sub-base Structural Failure",
                    riskLevel = "High",
                    predictionSummary = "Sustained water leakage on 5th Ave and Pine St indicates underground erosion that will lead to 3+ secondary potholes within 7 days.",
                    recommendationAction = "Schedule ground-penetrating radar inspection and hydro-jet drainage flush."
                ),
                PredictiveMaintenanceEntity(
                    wardName = "Ward 1 - Downtown Core",
                    issueType = "Electrical Transformer Overload",
                    riskLevel = "Medium",
                    predictionSummary = "Substation load fluctuations predict potential streetlight outages along Oak St during peak heat hours.",
                    recommendationAction = "Perform thermal imaging audit on Substation 4 transformers."
                )
            )
            dao.insertPredictiveMaintenance(predictiveList)

            // AI Executive Report Seed
            val report = AIReportEntity(
                title = "Mayor's Morning Smart City Digest",
                reportType = "Executive Brief",
                contentMarkdown = """
                    # 🏙️ Mayor's Daily Smart City Executive Summary
                    **System Status**: Operational | **Active City Health Score**: 81.5 / 100

                    ### 🎯 Key Performance Highlights
                    - **Total Incidents Analyzed by Gemma AI**: 45 Active Issues across 6 Wards.
                    - **Critical Incident Resolution Speed**: Improved by **18.4%** this week.
                    - **Top Concern Zone**: **Ward 5 (Industrial Hub)** requires immediate sanitation reinforcement.

                    ### 🤖 Gemma AI Strategic Directives
                    1. **Sanitation Dispatch**: Immediate surge deployment of 2 waste compactors to Ward 5.
                    2. **Public Works Synergy**: Repave 5th Ave pothole cluster concurrently with water main repair on Pine St to save $14,200 in municipal mobilization costs.
                    3. **Citizen Sentiment Index**: Positive trust rating increased to **89.2%** following rapid resolution on Oak St Streetlight Grid.
                """.trimIndent()
            )
            dao.insertAIReport(report)

            // Notifications
            dao.insertNotification(
                NotificationEntity(
                    userId = "c1",
                    title = "Complaint Progress Update",
                    message = "Elena Rostova (Public Works) has been assigned to your pothole report on 5th Avenue.",
                    complaintId = 1
                )
            )
            dao.insertNotification(
                NotificationEntity(
                    userId = "c1",
                    title = "Issue Resolved! 🎉",
                    message = "Your reported broken streetlight grid on Oak Street has been fully restored by David Chen.",
                    complaintId = 3
                )
            )
        }
    }
}
