package com.example.data.model

enum class UserRole {
    CITIZEN,
    WORKER,
    ADMIN
}
