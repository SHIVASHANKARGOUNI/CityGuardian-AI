package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val department: String? = null,
    val phone: String = "+1 (555) 019-2834",
    val avatarUrl: String? = null
)

@Entity(tableName = "complaints")
data class ComplaintEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val category: String, // Garbage, Potholes, Road Damage, Water Leakage, Broken Streetlights, Drainage, Traffic Signal, Illegal Dumping, Trees, Public Property Damage, Others
    val severity: String, // Low, Medium, High, Critical
    val priority: String, // P1, P2, P3, P4
    val status: String, // Submitted, Accepted, Assigned, In Progress, Resolved, Closed
    val citizenId: String,
    val citizenName: String,
    val wardName: String, // Ward 1 - Downtown, Ward 2 - Metro South, etc.
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val imageUri: String? = null,
    val beforeImageUri: String? = null,
    val afterImageUri: String? = null,
    val voiceText: String? = null,
    val aiReasoning: String, // Gemma explanation
    val detectedObjects: String = "", // YOLO object tags
    val isDuplicate: Boolean = false,
    val duplicateOfId: Int? = null,
    val duplicateCount: Int = 0,
    val department: String,
    val assignedWorkerId: String? = null,
    val assignedWorkerName: String? = null,
    val estimatedHours: Int = 24,
    val createdAt: Long = System.currentTimeMillis(),
    val resolvedAt: Long? = null,
    val resolutionNotes: String? = null
)

@Entity(tableName = "departments")
data class DepartmentEntity(
    @PrimaryKey val id: String,
    val name: String,
    val iconName: String,
    val headName: String,
    val totalPending: Int,
    val activeWorkersCount: Int
)

@Entity(tableName = "workers")
data class WorkerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val department: String,
    val phone: String,
    val status: String, // Available, On-Site, Off-Duty
    val completedJobsCount: Int,
    val rating: Float
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val title: String,
    val message: String,
    val complaintId: Int? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "city_wards")
data class CityWardEntity(
    @PrimaryKey val wardId: String,
    val wardName: String,
    val healthScore: Int, // 0 - 100
    val roadConditionScore: Int,
    val garbageIndexScore: Int,
    val cleanlinessScore: Int,
    val waterLeakageIndexScore: Int,
    val streetlightsUptimePercent: Int,
    val activeComplaintCount: Int
)

@Entity(tableName = "predictive_maintenance")
data class PredictiveMaintenanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val wardName: String,
    val issueType: String,
    val riskLevel: String, // Critical, High, Medium
    val predictionSummary: String,
    val recommendationAction: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_reports")
data class AIReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val reportType: String, // Mayor Daily Brief, Predictive Risk Alert, Ward Health Audit
    val contentMarkdown: String,
    val generatedAt: Long = System.currentTimeMillis()
)
