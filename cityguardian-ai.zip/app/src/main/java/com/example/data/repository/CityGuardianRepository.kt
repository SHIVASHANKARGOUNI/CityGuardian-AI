package com.example.data.repository

import com.example.data.dao.CityGuardianDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class CityGuardianRepository(private val dao: CityGuardianDao) {

    val allComplaints: Flow<List<ComplaintEntity>> = dao.getAllComplaints()
    val allDepartments: Flow<List<DepartmentEntity>> = dao.getAllDepartments()
    val allWorkers: Flow<List<WorkerEntity>> = dao.getAllWorkers()
    val allUsers: Flow<List<UserEntity>> = dao.getAllUsers()
    val wardScores: Flow<List<CityWardEntity>> = dao.getAllWardScores()
    val predictiveList: Flow<List<PredictiveMaintenanceEntity>> = dao.getPredictiveMaintenanceList()
    val aiReports: Flow<List<AIReportEntity>> = dao.getAIReports()

    fun getComplaintsByCitizen(citizenId: String): Flow<List<ComplaintEntity>> =
        dao.getComplaintsByCitizen(citizenId)

    fun getComplaintsByWorker(workerId: String): Flow<List<ComplaintEntity>> =
        dao.getComplaintsByWorker(workerId)

    fun getNotificationsForUser(userId: String): Flow<List<NotificationEntity>> =
        dao.getNotificationsForUser(userId)

    suspend fun getComplaintById(id: Int): ComplaintEntity? = dao.getComplaintById(id)

    suspend fun submitComplaint(complaint: ComplaintEntity): Long {
        return dao.insertComplaint(complaint)
    }

    suspend fun updateComplaint(complaint: ComplaintEntity) {
        dao.updateComplaint(complaint)
    }

    suspend fun assignWorkerToComplaint(complaintId: Int, workerId: String, workerName: String) {
        val existing = dao.getComplaintById(complaintId) ?: return
        val updated = existing.copy(
            assignedWorkerId = workerId,
            assignedWorkerName = workerName,
            status = "Assigned"
        )
        dao.updateComplaint(updated)

        // Notify Citizen
        dao.insertNotification(
            NotificationEntity(
                userId = existing.citizenId,
                title = "Worker Assigned 👷‍♂️",
                message = "$workerName has been assigned to your report: '${existing.title}'.",
                complaintId = complaintId
            )
        )
    }

    suspend fun resolveComplaint(
        complaintId: Int,
        beforeImageUri: String?,
        afterImageUri: String?,
        resolutionNotes: String
    ) {
        val existing = dao.getComplaintById(complaintId) ?: return
        val updated = existing.copy(
            status = "Resolved",
            resolvedAt = System.currentTimeMillis(),
            beforeImageUri = beforeImageUri ?: existing.imageUri,
            afterImageUri = afterImageUri,
            resolutionNotes = resolutionNotes
        )
        dao.updateComplaint(updated)

        existing.assignedWorkerId?.let { workerId ->
            dao.incrementWorkerJobCount(workerId)
        }

        // Notify Citizen
        dao.insertNotification(
            NotificationEntity(
                userId = existing.citizenId,
                title = "Complaint Resolved! 🎉",
                message = "Your issue '${existing.title}' has been marked resolved. Thank you for making our city safer!",
                complaintId = complaintId
            )
        )
    }

    suspend fun getUser(id: String): UserEntity? = dao.getUserById(id)

    suspend fun getUserByEmail(email: String): UserEntity? = dao.getUserByEmail(email)

    suspend fun saveUser(user: UserEntity) = dao.insertUser(user)

    suspend fun insertWorker(worker: WorkerEntity) = dao.insertWorkers(listOf(worker))

    suspend fun markNotificationsRead(userId: String) = dao.markAllNotificationsRead(userId)

    suspend fun addAIReport(report: AIReportEntity) = dao.insertAIReport(report)
}
