package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CityGuardianDao {
    // Users
    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY name ASC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE role = :role")
    fun getUsersByRole(role: UserRole): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    // Complaints
    @Query("SELECT * FROM complaints ORDER BY createdAt DESC")
    fun getAllComplaints(): Flow<List<ComplaintEntity>>

    @Query("SELECT * FROM complaints WHERE citizenId = :citizenId ORDER BY createdAt DESC")
    fun getComplaintsByCitizen(citizenId: String): Flow<List<ComplaintEntity>>

    @Query("SELECT * FROM complaints WHERE assignedWorkerId = :workerId ORDER BY createdAt DESC")
    fun getComplaintsByWorker(workerId: String): Flow<List<ComplaintEntity>>

    @Query("SELECT * FROM complaints WHERE id = :id")
    suspend fun getComplaintById(id: Int): ComplaintEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplaint(complaint: ComplaintEntity): Long

    @Update
    suspend fun updateComplaint(complaint: ComplaintEntity)

    @Query("DELETE FROM complaints WHERE id = :id")
    suspend fun deleteComplaintById(id: Int)

    // Departments & Workers
    @Query("SELECT * FROM departments")
    fun getAllDepartments(): Flow<List<DepartmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDepartments(departments: List<DepartmentEntity>)

    @Query("SELECT * FROM workers")
    fun getAllWorkers(): Flow<List<WorkerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkers(workers: List<WorkerEntity>)

    @Query("UPDATE workers SET completedJobsCount = completedJobsCount + 1 WHERE id = :workerId")
    suspend fun incrementWorkerJobCount(workerId: String)

    // Notifications
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY timestamp DESC")
    fun getNotificationsForUser(userId: String): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllNotificationsRead(userId: String)

    // City Wards & Scores
    @Query("SELECT * FROM city_wards ORDER BY healthScore ASC")
    fun getAllWardScores(): Flow<List<CityWardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWardScores(wards: List<CityWardEntity>)

    // Predictive Maintenance
    @Query("SELECT * FROM predictive_maintenance ORDER BY timestamp DESC")
    fun getPredictiveMaintenanceList(): Flow<List<PredictiveMaintenanceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPredictiveMaintenance(items: List<PredictiveMaintenanceEntity>)

    // AI Reports
    @Query("SELECT * FROM ai_reports ORDER BY generatedAt DESC")
    fun getAIReports(): Flow<List<AIReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAIReport(report: AIReportEntity)
}
