package com.example.ui.citizen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ComplaintEntity
import com.example.ui.common.SeverityBadge
import com.example.ui.theme.*

@Composable
fun NearbyMapScreen(
    complaints: List<ComplaintEntity>
) {
    var isHeatmapMode by remember { mutableStateOf(false) }
    var selectedComplaint by remember { mutableStateOf<ComplaintEntity?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Map Controls Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Smart City Incident Map",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${complaints.size} Geo-Tagged Reports",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FilterChip(
                    selected = isHeatmapMode,
                    onClick = { isHeatmapMode = !isHeatmapMode },
                    label = { Text(if (isHeatmapMode) "Heatmap ON" else "Pins Mode") },
                    leadingIcon = {
                        Icon(
                            imageVector = if (isHeatmapMode) Icons.Default.Layers else Icons.Default.Place,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )
            }
        }

        // Map Canvas Simulator
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(if (isHeatmapMode) DarkBackground else LightSurfaceVariant)
        ) {
            // Simulated Grid Lines
            Column(modifier = Modifier.fillMaxSize()) {
                repeat(8) {
                    Divider(color = Color.Gray.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 30.dp))
                }
            }

            // Render Incident Markers or Heatmap Blobs
            complaints.forEachIndexed { index, complaint ->
                val posX = (0.2f + (index * 0.18f) % 0.65f)
                val posY = (0.25f + (index * 0.22f) % 0.55f)

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = (posX * 300).dp, top = (posY * 400).dp)
                ) {
                    if (isHeatmapMode) {
                        // Heatmap Glowing Blob
                        val blobColor = when (complaint.severity) {
                            "Critical" -> DarkCritical.copy(alpha = 0.6f)
                            "High" -> CityAmberWarning.copy(alpha = 0.5f)
                            else -> CityBluePrimary.copy(alpha = 0.4f)
                        }
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(blobColor)
                                .clickable { selectedComplaint = complaint }
                        )
                    } else {
                        // Map Pin Marker
                        val pinColor = when (complaint.severity) {
                            "Critical" -> DarkCritical
                            "High" -> CityAmberWarning
                            else -> CityBluePrimary
                        }
                        Surface(
                            onClick = { selectedComplaint = complaint },
                            shape = CircleShape,
                            color = pinColor,
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = when (complaint.category) {
                                        "Potholes" -> Icons.Default.AddRoad
                                        "Garbage" -> Icons.Default.Delete
                                        "Water Leakage" -> Icons.Default.WaterDrop
                                        "Broken Streetlights" -> Icons.Default.Light
                                        else -> Icons.Default.Warning
                                    },
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Selected Marker Preview Sheet
            selectedComplaint?.let { selected ->
                Card(
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SeverityBadge(severity = selected.severity)
                            IconButton(onClick = { selectedComplaint = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Close")
                            }
                        }

                        Text(
                            text = selected.title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Text(
                            text = "📍 ${selected.address} • ${selected.wardName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = "Gemma AI: ${selected.aiReasoning}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}
