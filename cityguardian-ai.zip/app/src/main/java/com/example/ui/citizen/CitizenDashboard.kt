package com.example.ui.citizen

import android.graphics.Bitmap
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ai.GemmaAnalysisResult
import com.example.data.model.CityWardEntity
import com.example.data.model.ComplaintEntity
import com.example.data.model.UserEntity

@Composable
fun CitizenDashboard(
    currentUser: UserEntity,
    complaints: List<ComplaintEntity>,
    wardScores: List<CityWardEntity>,
    isAnalyzing: Boolean,
    gemmaAnalysis: GemmaAnalysisResult?,
    duplicateWarning: String?,
    chatMessages: List<com.example.ui.ChatMessage>,
    onRunAnalysis: (text: String, voiceText: String?, imageBitmap: Bitmap?, lat: Double, lng: Double) -> Unit,
    onSubmitReport: (title: String, description: String, wardName: String, lat: Double, lng: Double, address: String, imageUri: String?, voiceText: String?) -> Unit,
    onSendMessage: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBar(
                    containerColor = Color.Transparent,
                    windowInsets = WindowInsets(0, 0, 0, 0)
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(if (selectedTab == 0) Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Home") },
                        label = { Text("Home", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(if (selectedTab == 1) Icons.Filled.AddCircle else Icons.Outlined.AddCircle, contentDescription = "Report") },
                        label = { Text("Report", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(if (selectedTab == 2) Icons.Filled.Assignment else Icons.Outlined.Assignment, contentDescription = "Track") },
                        label = { Text("Track", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(if (selectedTab == 3) Icons.Filled.Map else Icons.Outlined.Map, contentDescription = "Map") },
                        label = { Text("Map", fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                    NavigationBarItem(
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        icon = { Icon(if (selectedTab == 4) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome, contentDescription = "Gemma AI") },
                        label = { Text("Gemma AI", fontWeight = if (selectedTab == 4) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> CitizenHomeScreen(
                    currentUser = currentUser,
                    complaints = complaints,
                    wardScores = wardScores,
                    onReportClick = { selectedTab = 1 },
                    onTrackClick = { selectedTab = 2 },
                    onComplaintClick = { selectedTab = 2 }
                )
                1 -> ReportIssueScreen(
                    isAnalyzing = isAnalyzing,
                    gemmaAnalysis = gemmaAnalysis,
                    duplicateWarning = duplicateWarning,
                    onRunAnalysis = onRunAnalysis,
                    onSubmitReport = { title, desc, ward, lat, lng, addr, img, voice ->
                        onSubmitReport(title, desc, ward, lat, lng, addr, img, voice)
                        selectedTab = 2 // Switch to track tab after submit
                    }
                )
                2 -> TrackComplaintsScreen(complaints = complaints)
                3 -> NearbyMapScreen(complaints = complaints)
                4 -> GemmaAssistantScreen(
                    messages = chatMessages,
                    onSendMessage = onSendMessage
                )
            }
        }
    }
}
