package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Color Palette
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate100 = Color(0xFFF1F5F9)
val Slate50  = Color(0xFFF8FAFC)

val Emerald500 = Color(0xFF10B981)
val Emerald600 = Color(0xFF059669)
val Emerald700 = Color(0xFF047857)
val Emerald100 = Color(0xFFD1FAE5)

val Amber500 = Color(0xFFF59E0B)
val Amber600 = Color(0xFFD97706)
val Amber100 = Color(0xFFFEF3C7)

val Red500 = Color(0xFFEF4444)
val Red600 = Color(0xFFDC2626)
val Red100 = Color(0xFFFEE2E2)

val Blue500 = Color(0xFF3B82F6)
val Blue600 = Color(0xFF2563EB)
val Blue100 = Color(0xFFDBEAFE)

val Purple500 = Color(0xFF8B5CF6)

// Semantic colors
val CityNavyPrimary = Slate900
val CityNavySecondary = Slate800
val CityBluePrimary = Blue600
val CityEmeraldAccent = Emerald500
val CityAmberWarning = Amber500
val CityRedCritical = Red500

val LightBackground = Slate50
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Slate100

val DarkBackground = Slate900
val DarkSurface = Slate800
val DarkSurfaceVariant = Slate700
val DarkPrimary = Emerald500
val DarkSecondary = Amber500
val DarkAccent = Blue500
val DarkCritical = Red500

// Status Colors
val StatusSubmitted = Blue500
val StatusAccepted = Purple500
val StatusAssigned = Amber500
val StatusInProgress = Color(0xFFF97316)
val StatusResolved = Emerald500
val StatusClosed = Slate500

