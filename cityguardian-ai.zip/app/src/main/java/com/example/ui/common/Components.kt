package com.example.ui.common

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.ui.theme.*

@Composable
fun SeverityBadge(severity: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when (severity.lowercase()) {
        "critical" -> DarkCritical to Color.White
        "high" -> CityAmberWarning to Color.White
        "medium" -> CityBluePrimary to Color.White
        else -> CityEmeraldAccent to Color.White
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (severity.equals("critical", true)) Icons.Default.Warning else Icons.Default.Info,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = severity.uppercase(),
                color = textColor,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            )
        }
    }
}

@Composable
fun StatusPill(status: String, modifier: Modifier = Modifier) {
    val color = when (status.lowercase()) {
        "submitted" -> StatusSubmitted
        "accepted" -> StatusAccepted
        "assigned" -> StatusAssigned
        "in progress" -> StatusInProgress
        "resolved" -> StatusResolved
        else -> StatusClosed
    }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color, CircleShape)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = status,
            color = color,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
        )
    }
}

@Composable
fun RoleHeaderBar(
    currentUser: UserEntity,
    unreadNotificationCount: Int,
    onSwitchRoleClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onLandingClick: () -> Unit,
    onVerificationClick: () -> Unit = {}
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.clickable { onLandingClick() }
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(CityBluePrimary, CityEmeraldAccent)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "CityGuardian Logo",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = "CityGuardian AI",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Text(
                        text = "Gemma Smart Platform",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.secondary
                        )
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // User Verification Shield Button
                IconButton(onClick = onVerificationClick) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "User Verification Steps",
                        tint = CityEmeraldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Role Badge
                AssistChip(
                    onClick = onSwitchRoleClick,
                    label = {
                        Text(
                            text = when (currentUser.role) {
                                UserRole.CITIZEN -> "Citizen"
                                UserRole.WORKER -> "Field Worker"
                                UserRole.ADMIN -> "Government Officer"
                            },
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = when (currentUser.role) {
                                UserRole.CITIZEN -> Icons.Default.Person
                                UserRole.WORKER -> Icons.Default.Engineering
                                UserRole.ADMIN -> Icons.Default.AccountBalance
                            },
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        labelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )

                // Notification Bell
                IconButton(onClick = onNotificationClick) {
                    BadgedBox(
                        badge = {
                            if (unreadNotificationCount > 0) {
                                Badge { Text("$unreadNotificationCount") }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RoleSwitchModal(
    currentRole: UserRole,
    onRoleSelected: (UserRole) -> Unit,
    onDismiss: () -> Unit,
    onOpenVerificationSteps: () -> Unit = {}
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.ManageAccounts, contentDescription = null, tint = CityBluePrimary)
                Text("Select Workspace Role", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "CityGuardian AI features role-based views. Switch roles below to test all system capabilities:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                RoleOptionCard(
                    title = "Citizen Portal",
                    subtitle = "Submit complaints, Whisper voice reports, track progress & chat with Gemma AI.",
                    icon = Icons.Default.Person,
                    isSelected = currentRole == UserRole.CITIZEN,
                    onClick = { onRoleSelected(UserRole.CITIZEN); onDismiss() }
                )

                RoleOptionCard(
                    title = "Field Worker Terminal",
                    subtitle = "Manage assigned tickets, GPS map directions, upload Before/After photos & resolve tasks.",
                    icon = Icons.Default.Engineering,
                    isSelected = currentRole == UserRole.WORKER,
                    onClick = { onRoleSelected(UserRole.WORKER); onDismiss() }
                )

                RoleOptionCard(
                    title = "Government & Mayor Dashboard",
                    subtitle = "Executive analytics, Mayor AI Briefings, Ward Health Scores & Predictive Maintenance.",
                    icon = Icons.Default.AccountBalance,
                    isSelected = currentRole == UserRole.ADMIN,
                    onClick = { onRoleSelected(UserRole.ADMIN); onDismiss() }
                )

                OutlinedButton(
                    onClick = { onDismiss(); onOpenVerificationSteps() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp), tint = CityEmeraldAccent)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("View Role Verification Steps & Rules", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun RoleOptionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = if (isSelected) ButtonDefaults.outlinedButtonBorder else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(28.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
            if (isSelected) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
