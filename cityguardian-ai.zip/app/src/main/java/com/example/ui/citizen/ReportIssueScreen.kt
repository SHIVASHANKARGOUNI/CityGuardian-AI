package com.example.ui.citizen

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.GemmaAnalysisResult
import com.example.ui.common.SeverityBadge
import com.example.ui.theme.*

@Composable
fun ReportIssueScreen(
    isAnalyzing: Boolean,
    gemmaAnalysis: GemmaAnalysisResult?,
    duplicateWarning: String?,
    onRunAnalysis: (text: String, voiceText: String?, imageBitmap: Bitmap?, lat: Double, lng: Double) -> Unit,
    onSubmitReport: (title: String, description: String, wardName: String, lat: Double, lng: Double, address: String, imageUri: String?, voiceText: String?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var wardName by remember { mutableStateOf("Ward 3 - Metro South") }
    var address by remember { mutableStateOf("742 5th Avenue, Metro South") }
    var latitude by remember { mutableStateOf(37.7749) }
    var longitude by remember { mutableStateOf(-122.4194) }

    var voiceText by remember { mutableStateOf<String?>(null) }
    var isRecordingVoice by remember { mutableStateOf(false) }

    var attachedImageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isSimulatingCamera by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Report Civic Issue",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
        )

        Text(
            text = "Google Gemma will parse your description, Whisper voice recording, and photo to analyze severity & dispatch workers.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Title Input
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Issue Title (Optional - Gemma auto-generates)") },
            placeholder = { Text("e.g. Deep pothole on 5th Ave") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        // Description Input
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Complaint Description *") },
            placeholder = { Text("Describe the issue in detail...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            shape = RoundedCornerShape(12.dp)
        )

        // Whisper Voice Recorder Simulation Section
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = CityBluePrimary)
                        Text("Whisper Voice Note Assistant", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            isRecordingVoice = !isRecordingVoice
                            if (!isRecordingVoice) {
                                voiceText = "Recorded audio: Deep crater-like pothole near the bus stop on 5th Avenue causing cars to swerve into oncoming lanes."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRecordingVoice) DarkCritical else CityBluePrimary
                        )
                    ) {
                        Text(if (isRecordingVoice) "Stop Recording" else "Record Voice Note")
                    }
                }

                if (isRecordingVoice) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text("Listening with Whisper AI speech recognition...", style = MaterialTheme.typography.bodySmall, color = CityBluePrimary)
                    }
                }

                voiceText?.let { vt ->
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "🎙️ Whisper Transcribed: \"$vt\"",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(10.dp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Camera Photo + YOLO Vision Simulation Section
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = CityEmeraldAccent)
                        Text("Photo Attachment & YOLO Vision", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            // Generate simulated issue image
                            val bmp = createSimulatedIssueBitmap()
                            attachedImageBitmap = bmp
                        }
                    ) {
                        Text("Capture Photo")
                    }
                }

                attachedImageBitmap?.let { bmp ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(12.dp))
                    ) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Captured Photo",
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .background(Color.Black.copy(alpha = 0.7f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "📷 Photo Attached & YOLO Visual Scanner Active",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }

        // GPS Location Pin
        OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("GPS Address Pin") },
            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        // Run Gemma Analysis CTA
        Button(
            onClick = {
                if (description.isBlank() && voiceText.isNullOrBlank()) {
                    description = "Hazardous road damage on 5th Avenue near the bus stop."
                }
                onRunAnalysis(description, voiceText, attachedImageBitmap, latitude, longitude)
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isAnalyzing,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CityBluePrimary)
        ) {
            if (isAnalyzing) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Gemma AI Analyzing Report...")
            } else {
                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Run Gemma AI Diagnosis")
            }
        }

        // Duplicate Warning Alert
        duplicateWarning?.let { dup ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CityAmberWarning.copy(alpha = 0.15f)),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Difference, contentDescription = null, tint = CityAmberWarning)
                    Text(dup, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }

        // Gemma AI Diagnosis Preview Box
        gemmaAnalysis?.let { result ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CityBluePrimary)
                            Text("Gemma AI Diagnosis Result", fontWeight = FontWeight.Bold)
                        }
                        SeverityBadge(severity = result.severity)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Category: ${result.category}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        Text("Department: ${result.department}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "🧠 Reasoning: ${result.aiReasoning}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )

                    Text(
                        text = "🎯 YOLO Detection: ${result.detectedObjects}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = {
                            onSubmitReport(
                                title.ifBlank { "${result.category} on $address" },
                                description.ifBlank { "Reported issue" },
                                wardName,
                                latitude,
                                longitude,
                                address,
                                if (attachedImageBitmap != null) "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600" else null,
                                voiceText
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CityEmeraldAccent)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Confirm & Submit Ticket")
                    }
                }
            }
        }
    }
}

private fun createSimulatedIssueBitmap(): Bitmap {
    val bitmap = Bitmap.createBitmap(400, 240, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint()

    // Background Asphalt
    paint.color = android.graphics.Color.DKGRAY
    canvas.drawRect(0f, 0f, 400f, 240f, paint)

    // Pothole Crater
    paint.color = android.graphics.Color.BLACK
    canvas.drawCircle(200f, 120f, 70f, paint)

    // Cracked borders
    paint.color = android.graphics.Color.LTGRAY
    paint.strokeWidth = 3f
    canvas.drawLine(130f, 120f, 80f, 90f, paint)
    canvas.drawLine(270f, 120f, 320f, 150f, paint)

    return bitmap
}
