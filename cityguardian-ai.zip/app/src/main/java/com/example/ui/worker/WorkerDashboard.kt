package com.example.ui.worker

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ComplaintEntity
import com.example.data.model.UserEntity
import com.example.ui.common.SeverityBadge
import com.example.ui.common.StatusPill
import com.example.ui.theme.*

@Composable
fun WorkerDashboard(
    currentUser: UserEntity,
    assignedComplaints: List<ComplaintEntity>,
    onResolveComplaint: (complaintId: Int, beforeImageUri: String?, afterImageUri: String?, notes: String) -> Unit
) {
    var workerStatus by remember { mutableStateOf("On-Duty") }
    var selectedTaskForDetail by remember { mutableStateOf<ComplaintEntity?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Worker Profile Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(CityAmberWarning),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Engineering, contentDescription = null, tint = Color.White)
                        }

                        Column {
                            Text(
                                text = currentUser.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Dept: ${currentUser.department ?: "Sanitation & Waste"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Status Toggle Button
                    FilterChip(
                        selected = true,
                        onClick = {
                            workerStatus = when (workerStatus) {
                                "On-Duty" -> "On-Site"
                                "On-Site" -> "Off-Duty"
                                else -> "On-Duty"
                            }
                        },
                        label = { Text(workerStatus) },
                        leadingIcon = {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (workerStatus == "Off-Duty") Color.Gray else CityEmeraldAccent)
                            )
                        }
                    )
                }

                // Daily Work Stats Banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    WorkerStatBadge(number = "${assignedComplaints.size}", label = "Pending Jobs")
                    WorkerStatBadge(number = "142", label = "Completed")
                    WorkerStatBadge(number = "4.9 ⭐", label = "Worker Rating")
                }

                // Worker Verification Status Pill
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CityAmberWarning.copy(alpha = 0.1f),
                    border = ButtonDefaults.outlinedButtonBorder
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = CityAmberWarning, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Admin Provisioned Badge #MUNI-8942-W • Verified Worker",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = CityAmberWarning
                            )
                        }
                        Text("ACTIVE ✔️", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CityEmeraldAccent)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Assigned Tasks List Title
        PaddingValues(horizontal = 16.dp).let {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "My Assigned Field Tasks",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${assignedComplaints.size} Active",
                    style = MaterialTheme.typography.labelSmall,
                    color = CityBluePrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (assignedComplaints.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.TaskAlt,
                        contentDescription = null,
                        tint = CityEmeraldAccent,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "All Assigned Jobs Resolved!",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "New tickets assigned by Gemma AI will appear here.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(assignedComplaints) { task ->
                    WorkerTaskCard(
                        task = task,
                        onClick = { selectedTaskForDetail = task }
                    )
                }
            }
        }

        // Resolution Modal / Bottom Sheet Studio
        selectedTaskForDetail?.let { task ->
            WorkerResolutionStudioDialog(
                task = task,
                onDismiss = { selectedTaskForDetail = null },
                onResolve = { before, after, notes ->
                    onResolveComplaint(task.id, before, after, notes)
                    selectedTaskForDetail = null
                }
            )
        }
    }
}

@Composable
private fun WorkerStatBadge(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = number, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = CityBluePrimary)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WorkerTaskCard(
    task: ComplaintEntity,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SeverityBadge(severity = task.severity)
                StatusPill(status = task.status)
            }

            Text(text = task.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

            Text(
                text = "📍 ${task.address}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Est. Repair: ${task.estimatedHours} hrs",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )

                Button(
                    onClick = onClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CityBluePrimary)
                ) {
                    Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Resolve Ticket")
                }
            }
        }
    }
}

@Composable
private fun WorkerResolutionStudioDialog(
    task: ComplaintEntity,
    onDismiss: () -> Unit,
    onResolve: (beforeImage: String?, afterImage: String?, notes: String) -> Unit
) {
    var resolutionNotes by remember { mutableStateOf("Inspected site, cleared debris, and replaced faulty infrastructure modules. Site verified operational.") }
    var beforeAttached by remember { mutableStateOf(task.imageUri ?: "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600") }
    var afterAttached by remember { mutableStateOf("https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=600") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Build, contentDescription = null, tint = CityEmeraldAccent)
                Text("Resolve Ticket #${task.id}", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Title: ${task.title}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Text("Location: ${task.address}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Divider()

                Text("📷 Before & After Photo Verification:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(onClick = { /* simulated capture */ }, modifier = Modifier.weight(1f)) {
                        Text("Before Photo ✓", fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = { /* simulated capture */ }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = CityEmeraldAccent)) {
                        Text("After Photo ✓", fontSize = 11.sp)
                    }
                }

                OutlinedTextField(
                    value = resolutionNotes,
                    onValueChange = { resolutionNotes = it },
                    label = { Text("Worker Field Resolution Notes *") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onResolve(beforeAttached, afterAttached, resolutionNotes) },
                colors = ButtonDefaults.buttonColors(containerColor = CityEmeraldAccent)
            ) {
                Text("Mark Ticket Resolved")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
