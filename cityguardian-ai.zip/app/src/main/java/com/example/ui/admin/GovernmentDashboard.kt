package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.common.SeverityBadge
import com.example.ui.common.StatusPill
import com.example.ui.theme.*

@Composable
fun GovernmentDashboard(
    complaints: List<ComplaintEntity>,
    departments: List<DepartmentEntity>,
    workers: List<WorkerEntity>,
    wardScores: List<CityWardEntity>,
    predictiveList: List<PredictiveMaintenanceEntity>,
    aiReports: List<AIReportEntity>,
    allUsers: List<UserEntity> = emptyList(),
    onGenerateReport: () -> Unit,
    onAssignWorker: (complaintId: Int, workerId: String, workerName: String) -> Unit,
    onProvisionOfficer: (name: String, email: String, empId: String, dept: String) -> Unit = { _, _, _, _ -> },
    onProvisionWorker: (workerId: String, name: String, dept: String, area: String, phone: String) -> Unit = { _, _, _, _, _ -> }
) {
    var selectedAdminTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Government Navigation Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedAdminTab,
            edgePadding = 12.dp
        ) {
            Tab(selected = selectedAdminTab == 0, onClick = { selectedAdminTab = 0 }) {
                Text("Mayor Briefing", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedAdminTab == 1, onClick = { selectedAdminTab = 1 }) {
                Text("Provision Accounts", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, color = CityEmeraldAccent)
            }
            Tab(selected = selectedAdminTab == 2, onClick = { selectedAdminTab = 2 }) {
                Text("City Health Index", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedAdminTab == 3, onClick = { selectedAdminTab = 3 }) {
                Text("Predictive Risk", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedAdminTab == 4, onClick = { selectedAdminTab = 4 }) {
                Text("Worker Dispatch", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedAdminTab == 5, onClick = { selectedAdminTab = 5 }) {
                Text("Departments", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (selectedAdminTab) {
                0 -> MayorBriefingTab(
                    complaints = complaints,
                    aiReports = aiReports,
                    onGenerateReport = onGenerateReport
                )
                1 -> AccountProvisioningTab(
                    allUsers = allUsers,
                    departments = departments,
                    onProvisionOfficer = onProvisionOfficer,
                    onProvisionWorker = onProvisionWorker
                )
                2 -> CityHealthTab(wardScores = wardScores)
                3 -> PredictiveRiskTab(predictiveList = predictiveList)
                4 -> DispatchMatrixTab(
                    unassignedComplaints = complaints.filter { it.assignedWorkerId == null },
                    workers = workers,
                    onAssignWorker = onAssignWorker
                )
                5 -> DepartmentAnalyticsTab(
                    departments = departments,
                    workers = workers
                )
            }
        }
    }
}

@Composable
private fun MayorBriefingTab(
    complaints: List<ComplaintEntity>,
    aiReports: List<AIReportEntity>,
    onGenerateReport: () -> Unit
) {
    val total = complaints.size
    val resolved = complaints.count { it.status == "Resolved" }
    val pending = total - resolved
    val critical = complaints.count { it.severity == "Critical" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Government Officer Security Verification Banner
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = CityEmeraldAccent.copy(alpha = 0.12f),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = CityEmeraldAccent)
                        Column {
                            Text(
                                text = "Mayor Victoria Sterling • Government Officer Clearance",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "System Admin Authorized • Credential ID #GOV-AUTH-001 • Level 4 Cabinet Access",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Surface(
                        color = CityEmeraldAccent,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "LEVEL 4 AUTH",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // High-level KPI Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KPICard(number = "$total", label = "Total Tickets", color = CityBluePrimary, modifier = Modifier.weight(1f))
                KPICard(number = "$resolved", label = "Resolved", color = CityEmeraldAccent, modifier = Modifier.weight(1f))
                KPICard(number = "$pending", label = "Pending", color = CityAmberWarning, modifier = Modifier.weight(1f))
                KPICard(number = "$critical", label = "Critical", color = DarkCritical, modifier = Modifier.weight(1f))
            }
        }

        // Mayor AI Executive Summary Digest
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CityBluePrimary)
                            Text("Gemma Mayor Executive AI Briefing", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }

                        Button(
                            onClick = onGenerateReport,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CityBluePrimary)
                        ) {
                            Text("Refresh AI", fontSize = 11.sp)
                        }
                    }

                    val latestReport = aiReports.firstOrNull()?.contentMarkdown ?: "Generating Gemma executive synthesis..."
                    Text(
                        text = latestReport,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        // Recent Critical Incidents
        item {
            Text("Critical Emergency Tickets Requiring Mayor Oversight", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
        }

        items(complaints.filter { it.severity == "Critical" }) { criticalItem ->
            ElevatedCard(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(criticalItem.title, fontWeight = FontWeight.Bold)
                        Text(criticalItem.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    SeverityBadge(severity = criticalItem.severity)
                }
            }
        }
    }
}

@Composable
private fun CityHealthTab(wardScores: List<CityWardEntity>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("City Ward Health Index Scoreboard (0 - 100)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("Real-time algorithmic scoring based on road quality, cleanliness, streetlights & water leaks.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        items(wardScores) { ward ->
            WardScoreFullCard(ward = ward)
        }
    }
}

@Composable
private fun WardScoreFullCard(ward: CityWardEntity) {
    val healthColor = when {
        ward.healthScore >= 85 -> CityEmeraldAccent
        ward.healthScore >= 65 -> CityAmberWarning
        else -> DarkCritical
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(ward.wardName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Text("${ward.healthScore} / 100", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold), color = healthColor)
            }

            LinearProgressIndicator(
                progress = { ward.healthScore / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape),
                color = healthColor,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Road Condition: ${ward.roadConditionScore}%", style = MaterialTheme.typography.bodySmall)
                Text("Cleanliness: ${ward.cleanlinessScore}%", style = MaterialTheme.typography.bodySmall)
                Text("Streetlights: ${ward.streetlightsUptimePercent}%", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun PredictiveRiskTab(predictiveList: List<PredictiveMaintenanceEntity>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Analytics, contentDescription = null, tint = CityBluePrimary)
                Text("Gemma Predictive Infrastructure Engine", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
            Text("AI forecasting imminent road failures, waste accumulations, and water pipe leaks before failure.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        items(predictiveList) { item ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.issueType, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        SeverityBadge(severity = item.riskLevel)
                    }

                    Text("📍 Location: ${item.wardName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("🤖 Gemma Prediction: ${item.predictionSummary}", style = MaterialTheme.typography.bodyMedium)

                    Surface(
                        color = CityEmeraldAccent.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "💡 Recommended Action: ${item.recommendationAction}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = CityEmeraldAccent,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DispatchMatrixTab(
    unassignedComplaints: List<ComplaintEntity>,
    workers: List<WorkerEntity>,
    onAssignWorker: (complaintId: Int, workerId: String, workerName: String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Worker Dispatch Matrix", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("Assign available field crews to open tickets with 1-click.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (unassignedComplaints.isEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Text("All open tickets have been assigned to workers!", modifier = Modifier.padding(20.dp), fontWeight = FontWeight.Bold)
                }
            }
        } else {
            items(unassignedComplaints) { complaint ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(complaint.title, fontWeight = FontWeight.Bold)
                            SeverityBadge(severity = complaint.severity)
                        }

                        Text("Dept Needed: ${complaint.department}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)

                        Text("Select Worker to Dispatch:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            workers.filter { it.status != "Off-Duty" }.forEach { worker ->
                                OutlinedButton(
                                    onClick = { onAssignWorker(complaint.id, worker.id, worker.name) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${worker.name} (${worker.department})", fontSize = 12.sp)
                                        Text("Assign ➔", fontSize = 11.sp, color = CityBluePrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DepartmentAnalyticsTab(
    departments: List<DepartmentEntity>,
    workers: List<WorkerEntity>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Department & Worker Workload", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        items(departments) { dept ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(dept.name, fontWeight = FontWeight.Bold)
                        Text("Head: ${dept.headName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("${dept.totalPending} Pending", fontWeight = FontWeight.Bold, color = CityAmberWarning)
                        Text("${dept.activeWorkersCount} Crews Active", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun KPICard(number: String, label: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(number, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = color)
            Text(label, style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
        }
    }
}

@Composable
private fun AccountProvisioningTab(
    allUsers: List<UserEntity>,
    departments: List<DepartmentEntity>,
    onProvisionOfficer: (name: String, email: String, empId: String, dept: String) -> Unit,
    onProvisionWorker: (workerId: String, name: String, dept: String, area: String, phone: String) -> Unit
) {
    var officerName by remember { mutableStateOf("") }
    var officerEmail by remember { mutableStateOf("") }
    var officerEmpId by remember { mutableStateOf("") }
    var officerDept by remember { mutableStateOf("Municipal Administration") }

    var workerIdInput by remember { mutableStateOf("") }
    var workerNameInput by remember { mutableStateOf("") }
    var workerDeptInput by remember { mutableStateOf("Sanitation & Waste") }
    var workerAreaInput by remember { mutableStateOf("Ward 2 - Metro South") }
    var workerPhoneInput by remember { mutableStateOf("+1 (555) 392-1021") }

    var feedbackMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = CityEmeraldAccent.copy(alpha = 0.12f),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = CityEmeraldAccent, modifier = Modifier.size(32.dp))
                    Column {
                        Text(
                            text = "Administrator Provisioning Terminal",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Government Officers and Field Workers cannot self-register. Accounts are created and role-assigned exclusively by Municipal Administrators.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        feedbackMessage?.let { msg ->
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CityEmeraldAccent.copy(alpha = 0.2f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CityEmeraldAccent)
                        Text(msg, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = CityEmeraldAccent)
                    }
                }
            }
        }

        // Form 1: Provision Government Officer (Step 2)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = CityEmeraldAccent)
                        Text("Step 2: Provision Government Officer Account", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Text("Creates authorized Government Officer account with Role = Government Officer.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = officerName,
                        onValueChange = { officerName = it },
                        label = { Text("Officer Name (e.g. Priya Sharma)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = officerEmail,
                        onValueChange = { officerEmail = it },
                        label = { Text("Official Email (e.g. priya.officer@metrocity.gov)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = officerEmpId,
                        onValueChange = { officerEmpId = it },
                        label = { Text("Employee ID (e.g. GOV-OFF-401)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = officerDept,
                        onValueChange = { officerDept = it },
                        label = { Text("Department") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            if (officerName.isNotBlank() && officerEmail.isNotBlank()) {
                                onProvisionOfficer(officerName, officerEmail, officerEmpId, officerDept)
                                feedbackMessage = "Successfully provisioned Officer '$officerName' with Role = Government Officer!"
                                officerName = ""
                                officerEmail = ""
                                officerEmpId = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = CityEmeraldAccent)
                    ) {
                        Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Provision Government Officer Account")
                    }
                }
            }
        }

        // Form 2: Provision Field Worker (Step 3)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Engineering, contentDescription = null, tint = CityAmberWarning)
                        Text("Step 3: Provision Field Worker Account", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Text("Creates authorized Field Worker crew account with Role = Field Worker.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = workerIdInput,
                        onValueChange = { workerIdInput = it },
                        label = { Text("Worker Badge ID (e.g. WRK-8092)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = workerNameInput,
                        onValueChange = { workerNameInput = it },
                        label = { Text("Worker Name (e.g. Ravi Kumar)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = workerDeptInput,
                        onValueChange = { workerDeptInput = it },
                        label = { Text("Department (e.g. Sanitation & Waste)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = workerAreaInput,
                        onValueChange = { workerAreaInput = it },
                        label = { Text("Assigned Area (e.g. Ward 2 - Metro South)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            if (workerNameInput.isNotBlank()) {
                                onProvisionWorker(workerIdInput, workerNameInput, workerDeptInput, workerAreaInput, workerPhoneInput)
                                feedbackMessage = "Successfully provisioned Field Worker '$workerNameInput' with Role = Field Worker!"
                                workerNameInput = ""
                                workerIdInput = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = CityAmberWarning)
                    ) {
                        Icon(Icons.Default.Engineering, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Provision Field Worker Account")
                    }
                }
            }
        }

        // Section 3: Registered Database Users Directory
        item {
            Text("Municipal User Directory & Immutable Role Registry", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        items(allUsers) { user ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(user.name, fontWeight = FontWeight.Bold)
                        Text("${user.email} • ${user.department ?: "Civic Resident"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Surface(
                        color = when (user.role) {
                            UserRole.CITIZEN -> CityBluePrimary.copy(alpha = 0.2f)
                            UserRole.WORKER -> CityAmberWarning.copy(alpha = 0.2f)
                            UserRole.ADMIN -> CityEmeraldAccent.copy(alpha = 0.2f)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = when (user.role) {
                                UserRole.CITIZEN -> "CITIZEN"
                                UserRole.WORKER -> "FIELD WORKER"
                                UserRole.ADMIN -> "GOVT OFFICER"
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            color = when (user.role) {
                                UserRole.CITIZEN -> CityBluePrimary
                                UserRole.WORKER -> CityAmberWarning
                                UserRole.ADMIN -> CityEmeraldAccent
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
