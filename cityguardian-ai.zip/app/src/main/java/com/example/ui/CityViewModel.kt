package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GemmaAiService
import com.example.ai.GemmaAnalysisResult
import com.example.data.db.CityGuardianDatabase
import com.example.data.model.*
import com.example.data.repository.CityGuardianRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatMessage(
    val sender: String, // "User" or "Gemma AI"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class CityViewModel(application: Application) : AndroidViewModel(application) {

    private val db = CityGuardianDatabase.getDatabase(application, viewModelScope)
    val repository = CityGuardianRepository(db.cityGuardianDao())
    val gemmaService = GemmaAiService(application)

    // Current active user (Citizen, Worker, or Admin)
    private val _currentUser = MutableStateFlow(
        UserEntity("c1", "Alex Rivera", "alex.rivera@citizen.gov", UserRole.CITIZEN)
    )
    val currentUser: StateFlow<UserEntity> = _currentUser.asStateFlow()

    val allComplaints = repository.allComplaints.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val departments = repository.allDepartments.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val workers = repository.allWorkers.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val wardScores = repository.wardScores.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val predictiveList = repository.predictiveList.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val aiReports = repository.aiReports.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val userNotifications: StateFlow<List<NotificationEntity>> = _currentUser.flatMapLatest { user ->
        repository.getNotificationsForUser(user.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Citizen specific complaint list
    val citizenComplaints: StateFlow<List<ComplaintEntity>> = _currentUser.flatMapLatest { user ->
        repository.getComplaintsByCitizen(user.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Worker specific assigned complaint list
    val workerComplaints: StateFlow<List<ComplaintEntity>> = _currentUser.flatMapLatest { user ->
        repository.getComplaintsByWorker(user.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Gemma AI state during submission
    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _lastGemmaAnalysis = MutableStateFlow<GemmaAnalysisResult?>(null)
    val lastGemmaAnalysis: StateFlow<GemmaAnalysisResult?> = _lastGemmaAnalysis.asStateFlow()

    private val _duplicateWarning = MutableStateFlow<String?>(null)
    val duplicateWarning: StateFlow<String?> = _duplicateWarning.asStateFlow()

    // Gemma Chat State
    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage("Gemma AI", "Hello! I am Google Gemma, your 24/7 Smart City AI Assistant. Ask me anything about reporting issues, tracking status, municipal ward scores, or city services!")
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    val allUsers: StateFlow<List<UserEntity>> = repository.allUsers.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    fun loginUser(user: UserEntity) {
        viewModelScope.launch {
            _currentUser.value = user
        }
    }

    fun registerCitizen(
        name: String,
        email: String,
        phone: String,
        password: String,
        onSuccess: (UserEntity) -> Unit
    ) {
        viewModelScope.launch {
            val newCitizen = UserEntity(
                id = "c_${System.currentTimeMillis()}",
                name = name.ifBlank { "Citizen User" },
                email = email.ifBlank { "citizen@metrocity.gov" },
                role = UserRole.CITIZEN,
                phone = phone.ifBlank { "+1 (555) 019-2834" }
            )
            repository.saveUser(newCitizen)
            _currentUser.value = newCitizen
            onSuccess(newCitizen)
        }
    }

    fun provisionGovernmentOfficer(
        name: String,
        officialEmail: String,
        employeeId: String,
        department: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val officerUser = UserEntity(
                id = "gov_${employeeId.ifBlank { System.currentTimeMillis().toString() }}",
                name = name,
                email = officialEmail,
                role = UserRole.ADMIN,
                department = department
            )
            repository.saveUser(officerUser)
            onSuccess()
        }
    }

    fun provisionFieldWorker(
        workerId: String,
        name: String,
        department: String,
        assignedArea: String,
        phone: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val cleanId = workerId.ifBlank { "WRK-${System.currentTimeMillis() % 10000}" }
            val workerUser = UserEntity(
                id = "wrk_$cleanId",
                name = name,
                email = "$cleanId@city.gov",
                role = UserRole.WORKER,
                department = department,
                phone = phone.ifBlank { "+1 (555) 000-0000" }
            )
            val workerDetail = WorkerEntity(
                id = "wrk_$cleanId",
                name = name,
                department = department,
                phone = phone.ifBlank { "+1 (555) 000-0000" },
                status = "Available",
                completedJobsCount = 0,
                rating = 5.0f
            )
            repository.saveUser(workerUser)
            repository.insertWorker(workerDetail)
            onSuccess()
        }
    }

    fun switchUserRole(role: UserRole) {
        viewModelScope.launch {
            val newUser = when (role) {
                UserRole.CITIZEN -> UserEntity("c_rahul", "Rahul Verma", "rahul.citizen@metrocity.gov", UserRole.CITIZEN)
                UserRole.WORKER -> UserEntity("w_ravi", "Ravi Kumar", "ravi.worker@metrocity.gov", UserRole.WORKER, "Sanitation & Waste")
                UserRole.ADMIN -> UserEntity("a_priya", "Priya Sharma", "priya.officer@metrocity.gov", UserRole.ADMIN, "Municipal Administration")
            }
            repository.saveUser(newUser)
            _currentUser.value = newUser
        }
    }

    fun analyzeAndPreviewReport(
        text: String,
        voiceText: String?,
        bitmap: Bitmap?,
        lat: Double,
        lng: Double
    ) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _duplicateWarning.value = null

            val analysis = gemmaService.analyzeComplaint(text, voiceText, bitmap, lat, lng)
            _lastGemmaAnalysis.value = analysis

            // Check duplicates
            val dupCheck = gemmaService.checkDuplicates(text, analysis.category, lat, lng, allComplaints.value)
            if (dupCheck.isDuplicate) {
                _duplicateWarning.value = dupCheck.reasoning
            }

            _isAnalyzing.value = false
        }
    }

    fun submitReport(
        title: String,
        description: String,
        wardName: String,
        lat: Double,
        lng: Double,
        address: String,
        imageUri: String?,
        voiceText: String?
    ) {
        viewModelScope.launch {
            val analysis = _lastGemmaAnalysis.value ?: gemmaService.analyzeComplaint(description, voiceText, null, lat, lng)

            val newComplaint = ComplaintEntity(
                title = title.ifBlank { "${analysis.category} Reported near $address" },
                description = description,
                category = analysis.category,
                severity = analysis.severity,
                priority = analysis.priority,
                status = "Submitted",
                citizenId = currentUser.value.id,
                citizenName = currentUser.value.name,
                wardName = wardName,
                latitude = lat,
                longitude = lng,
                address = address,
                imageUri = imageUri,
                voiceText = voiceText,
                aiReasoning = analysis.aiReasoning,
                detectedObjects = analysis.detectedObjects,
                department = analysis.department,
                estimatedHours = analysis.estimatedHours,
                createdAt = System.currentTimeMillis()
            )

            repository.submitComplaint(newComplaint)
            _lastGemmaAnalysis.value = null
            _duplicateWarning.value = null
        }
    }

    fun assignWorker(complaintId: Int, workerId: String, workerName: String) {
        viewModelScope.launch {
            repository.assignWorkerToComplaint(complaintId, workerId, workerName)
        }
    }

    fun resolveComplaint(
        complaintId: Int,
        beforeImageUri: String?,
        afterImageUri: String?,
        notes: String
    ) {
        viewModelScope.launch {
            repository.resolveComplaint(complaintId, beforeImageUri, afterImageUri, notes)
        }
    }

    fun sendChatMessage(userText: String) {
        if (userText.isBlank()) return
        val currentList = _chatMessages.value.toMutableList()
        currentList.add(ChatMessage("User", userText))
        _chatMessages.value = currentList

        viewModelScope.launch {
            val response = gemmaService.chatWithGemma(userText, currentUser.value.name)
            val updated = _chatMessages.value.toMutableList()
            updated.add(ChatMessage("Gemma AI", response))
            _chatMessages.value = updated
        }
    }

    fun generateNewMayorReport() {
        viewModelScope.launch {
            val summary = gemmaService.generateMayorExecutiveSummary(allComplaints.value)
            val newReport = AIReportEntity(
                title = "Live Mayor Executive AI Briefing",
                reportType = "Executive Briefing",
                contentMarkdown = summary
            )
            repository.addAIReport(newReport)
        }
    }

    fun markNotificationsRead() {
        viewModelScope.launch {
            repository.markNotificationsRead(currentUser.value.id)
        }
    }
}
