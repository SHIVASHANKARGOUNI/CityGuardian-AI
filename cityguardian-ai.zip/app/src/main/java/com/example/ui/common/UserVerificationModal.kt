package com.example.ui.common

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.ui.theme.*

@Composable
fun UserVerificationDialog(
    currentUser: UserEntity,
    onDismiss: () -> Unit
) {
    var selectedTabRole by remember { mutableStateOf(currentUser.role) }
    var verificationInputCode by remember { mutableStateOf("") }
    var verificationSuccessMessage by remember { mutableStateOf<String?>(null) }
    var isVerifying by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CityEmeraldAccent.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "User Verification",
                        tint = CityEmeraldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "User Identity & Verification Steps",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Role-Based Access Control & Credential Protocol",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Role Selector Tabs inside Verification Modal
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = selectedTabRole == UserRole.CITIZEN,
                        onClick = { selectedTabRole = UserRole.CITIZEN; verificationSuccessMessage = null },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 3)
                    ) {
                        Text("Citizen", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    SegmentedButton(
                        selected = selectedTabRole == UserRole.WORKER,
                        onClick = { selectedTabRole = UserRole.WORKER; verificationSuccessMessage = null },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 3)
                    ) {
                        Text("Field Worker", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    SegmentedButton(
                        selected = selectedTabRole == UserRole.ADMIN,
                        onClick = { selectedTabRole = UserRole.ADMIN; verificationSuccessMessage = null },
                        shape = SegmentedButtonDefaults.itemShape(index = 2, count = 3)
                    ) {
                        Text("Gov Officer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Authentication Governance Banner
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when (selectedTabRole) {
                        UserRole.CITIZEN -> CityBluePrimary.copy(alpha = 0.1f)
                        UserRole.WORKER -> CityAmberWarning.copy(alpha = 0.1f)
                        UserRole.ADMIN -> CityEmeraldAccent.copy(alpha = 0.1f)
                    },
                    border = ButtonDefaults.outlinedButtonBorder
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = when (selectedTabRole) {
                                UserRole.CITIZEN -> Icons.Default.HowToReg
                                UserRole.WORKER -> Icons.Default.AdminPanelSettings
                                UserRole.ADMIN -> Icons.Default.Security
                            },
                            contentDescription = null,
                            tint = when (selectedTabRole) {
                                UserRole.CITIZEN -> CityBluePrimary
                                UserRole.WORKER -> CityAmberWarning
                                UserRole.ADMIN -> CityEmeraldAccent
                            }
                        )
                        Column {
                            Text(
                                text = when (selectedTabRole) {
                                    UserRole.CITIZEN -> "Citizen Registration Rules"
                                    UserRole.WORKER -> "Field Worker Provisioning Rules"
                                    UserRole.ADMIN -> "Government Officer Access Rules"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = when (selectedTabRole) {
                                    UserRole.CITIZEN -> "• Anyone can self-register with Email & Password.\n• Roles cannot be self-escalated to Field Worker or Admin."
                                    UserRole.WORKER -> "• Self-registration is strictly forbidden.\n• Account is created and provisioned by Government Admin."
                                    UserRole.ADMIN -> "• Self-registration is strictly forbidden.\n• Account is provisioned only by System Administrator."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Verification Pipeline Checklist
                Text(
                    text = "Verification Step Pipeline",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )

                when (selectedTabRole) {
                    UserRole.CITIZEN -> {
                        VerificationStepItem(
                            stepNumber = 1,
                            title = "Email & Phone OTP Authentication",
                            description = "Validates user contact info & prevents spam bot registrations.",
                            isCompleted = true,
                            badgeText = "VERIFIED ✔️"
                        )
                        VerificationStepItem(
                            stepNumber = 2,
                            title = "Civic Resident ID Audit",
                            description = "Verifies residency badge with municipal tax / voter database.",
                            isCompleted = true,
                            badgeText = "RESIDENT BADGE 🛡️"
                        )
                        VerificationStepItem(
                            stepNumber = 3,
                            title = "Ward Geofence Location Check",
                            description = "GPS bounds confirm active location inside Metro City Ward 1-6.",
                            isCompleted = true,
                            badgeText = "GEOFENCE PASS 📍"
                        )
                    }
                    UserRole.WORKER -> {
                        VerificationStepItem(
                            stepNumber = 1,
                            title = "Admin Account Provisioning",
                            description = "Account created by Dept Head with Employee ID #MUNI-8942-W.",
                            isCompleted = true,
                            badgeText = "ADMIN CREATED ✔️"
                        )
                        VerificationStepItem(
                            stepNumber = 2,
                            title = "Department & Skill Clearance",
                            description = "Certified in Sanitation & Heavy Equipment Hazard Protocols.",
                            isCompleted = true,
                            badgeText = "CERTIFIED 🛠️"
                        )
                        VerificationStepItem(
                            stepNumber = 3,
                            title = "Supervisor Approval & Device Linkage",
                            description = "Secure hardware terminal pairing for GPS field dispatch.",
                            isCompleted = true,
                            badgeText = "TERMINAL ACTIVE 📱"
                        )
                    }
                    UserRole.ADMIN -> {
                        VerificationStepItem(
                            stepNumber = 1,
                            title = "System Admin Authorization",
                            description = "Cabinet System Administrator cleared credentials for Mayor Office.",
                            isCompleted = true,
                            badgeText = "SYSADMIN AUTH ✔️"
                        )
                        VerificationStepItem(
                            stepNumber = 2,
                            title = "Government Credential Audit",
                            description = "Official ID #GOV-AUTH-001 with Level 4 Executive Authority.",
                            isCompleted = true,
                            badgeText = "LEVEL 4 AUTH 🏛️"
                        )
                        VerificationStepItem(
                            stepNumber = 3,
                            title = "Hardware Security Key & 2FA Token",
                            description = "Encrypted hardware token active for city-wide worker dispatch.",
                            isCompleted = true,
                            badgeText = "2FA MASTER KEY 🔐"
                        )
                    }
                }

                Divider()

                // Interactive Verification Test Box
                Text(
                    text = "Interactive Identity Verification Check",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = verificationInputCode,
                        onValueChange = { verificationInputCode = it },
                        label = {
                            Text(
                                when (selectedTabRole) {
                                    UserRole.CITIZEN -> "Enter Civic Resident ID (e.g. RES-9982)"
                                    UserRole.WORKER -> "Enter Municipal Worker Badge (e.g. MUNI-8942-W)"
                                    UserRole.ADMIN -> "Enter System Admin Security Key (e.g. GOV-AUTH-001)"
                                },
                                fontSize = 11.sp
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) }
                    )

                    Button(
                        onClick = {
                            isVerifying = true
                            verificationSuccessMessage = when (selectedTabRole) {
                                UserRole.CITIZEN -> "Identity Verified! Civic Resident Badge active for Alex Rivera (Ward 1)."
                                UserRole.WORKER -> "Badge Authorized! Marcus Vance verified as Field Worker (Sanitation Dept)."
                                UserRole.ADMIN -> "Security Token Approved! Mayor Victoria Sterling granted Level 4 Command Access."
                            }
                            isVerifying = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when (selectedTabRole) {
                                UserRole.CITIZEN -> CityBluePrimary
                                UserRole.WORKER -> CityAmberWarning
                                UserRole.ADMIN -> CityEmeraldAccent
                            }
                        )
                    ) {
                        if (isVerifying) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Run Credential Verification Check")
                        }
                    }

                    verificationSuccessMessage?.let { msg ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CityEmeraldAccent.copy(alpha = 0.15f),
                            border = ButtonDefaults.outlinedButtonBorder
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CityEmeraldAccent)
                                Text(
                                    text = msg,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = CityEmeraldAccent
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close Verification Panel", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun VerificationStepItem(
    stepNumber: Int,
    title: String,
    description: String,
    isCompleted: Boolean,
    badgeText: String
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = if (isCompleted) ButtonDefaults.outlinedButtonBorder else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (isCompleted) CityEmeraldAccent else MaterialTheme.colorScheme.outline),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "$stepNumber",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Surface(
                        color = CityEmeraldAccent.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = badgeText,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            color = CityEmeraldAccent,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
