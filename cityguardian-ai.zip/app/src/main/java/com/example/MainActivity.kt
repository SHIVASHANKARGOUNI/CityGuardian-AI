package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserRole
import com.example.ui.CityViewModel
import com.example.ui.admin.GovernmentDashboard
import com.example.ui.citizen.CitizenDashboard
import com.example.ui.common.RoleHeaderBar
import com.example.ui.common.RoleSwitchModal
import com.example.ui.common.UserVerificationDialog
import com.example.ui.landing.LandingScreen
import com.example.ui.theme.CityGuardianTheme
import com.example.ui.worker.WorkerDashboard

class MainActivity : ComponentActivity() {

    private val viewModel: CityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CityGuardianTheme {
                val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
                val allComplaints by viewModel.allComplaints.collectAsStateWithLifecycle()
                val citizenComplaints by viewModel.citizenComplaints.collectAsStateWithLifecycle()
                val workerComplaints by viewModel.workerComplaints.collectAsStateWithLifecycle()
                val departments by viewModel.departments.collectAsStateWithLifecycle()
                val workers by viewModel.workers.collectAsStateWithLifecycle()
                val wardScores by viewModel.wardScores.collectAsStateWithLifecycle()
                val predictiveList by viewModel.predictiveList.collectAsStateWithLifecycle()
                val aiReports by viewModel.aiReports.collectAsStateWithLifecycle()
                val notifications by viewModel.userNotifications.collectAsStateWithLifecycle()
                val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()

                val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
                val gemmaAnalysis by viewModel.lastGemmaAnalysis.collectAsStateWithLifecycle()
                val duplicateWarning by viewModel.duplicateWarning.collectAsStateWithLifecycle()
                val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()

                var showLanding by remember { mutableStateOf(true) }
                var showRoleModal by remember { mutableStateOf(false) }
                var showNotificationSheet by remember { mutableStateOf(false) }
                var showVerificationModal by remember { mutableStateOf(false) }

                Scaffold(
                    topBar = {
                        if (!showLanding) {
                            RoleHeaderBar(
                                currentUser = currentUser,
                                unreadNotificationCount = notifications.count { !it.isRead },
                                onSwitchRoleClick = { showRoleModal = true },
                                onNotificationClick = {
                                    showNotificationSheet = true
                                    viewModel.markNotificationsRead()
                                },
                                onLandingClick = { showLanding = true },
                                onVerificationClick = { showVerificationModal = true }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (showLanding) {
                            LandingScreen(
                                onRoleSelect = { role ->
                                    viewModel.switchUserRole(role)
                                    showLanding = false
                                },
                                onOpenVerificationModal = { showVerificationModal = true },
                                onRegisterCitizen = { name, email, phone, pwd ->
                                    viewModel.registerCitizen(name, email, phone, pwd) {
                                        showLanding = false
                                    }
                                },
                                allUsers = allUsers,
                                onSelectUser = { user ->
                                    viewModel.loginUser(user)
                                    showLanding = false
                                }
                            )
                        } else {
                            AnimatedContent(
                                targetState = currentUser.role,
                                label = "RoleViewTransition"
                            ) { role ->
                                when (role) {
                                    UserRole.CITIZEN -> CitizenDashboard(
                                        currentUser = currentUser,
                                        complaints = citizenComplaints.ifEmpty { allComplaints },
                                        wardScores = wardScores,
                                        isAnalyzing = isAnalyzing,
                                        gemmaAnalysis = gemmaAnalysis,
                                        duplicateWarning = duplicateWarning,
                                        chatMessages = chatMessages,
                                        onRunAnalysis = { text, voiceText, bitmap, lat, lng ->
                                            viewModel.analyzeAndPreviewReport(text, voiceText, bitmap, lat, lng)
                                        },
                                        onSubmitReport = { title, desc, ward, lat, lng, addr, img, voice ->
                                            viewModel.submitReport(title, desc, ward, lat, lng, addr, img, voice)
                                        },
                                        onSendMessage = { query ->
                                            viewModel.sendChatMessage(query)
                                        }
                                    )

                                    UserRole.WORKER -> WorkerDashboard(
                                        currentUser = currentUser,
                                        assignedComplaints = workerComplaints.ifEmpty { allComplaints.filter { it.assignedWorkerId == currentUser.id } },
                                        onResolveComplaint = { id, before, after, notes ->
                                            viewModel.resolveComplaint(id, before, after, notes)
                                        }
                                    )

                                    UserRole.ADMIN -> GovernmentDashboard(
                                        complaints = allComplaints,
                                        departments = departments,
                                        workers = workers,
                                        wardScores = wardScores,
                                        predictiveList = predictiveList,
                                        aiReports = aiReports,
                                        allUsers = allUsers,
                                        onGenerateReport = {
                                            viewModel.generateNewMayorReport()
                                        },
                                        onAssignWorker = { complaintId, workerId, workerName ->
                                            viewModel.assignWorker(complaintId, workerId, workerName)
                                        },
                                        onProvisionOfficer = { name, email, empId, dept ->
                                            viewModel.provisionGovernmentOfficer(name, email, empId, dept)
                                        },
                                        onProvisionWorker = { workerId, name, dept, area, phone ->
                                            viewModel.provisionFieldWorker(workerId, name, dept, area, phone)
                                        }
                                    )
                                }
                            }
                        }

                        // Role Switcher Modal
                        if (showRoleModal) {
                            RoleSwitchModal(
                                currentRole = currentUser.role,
                                onRoleSelected = { role ->
                                    viewModel.switchUserRole(role)
                                    showLanding = false
                                },
                                onDismiss = { showRoleModal = false },
                                onOpenVerificationSteps = { showVerificationModal = true }
                            )
                        }

                        // User Verification Steps Modal
                        if (showVerificationModal) {
                            UserVerificationDialog(
                                currentUser = currentUser,
                                onDismiss = { showVerificationModal = false }
                            )
                        }

                        // Notifications Modal Sheet
                        if (showNotificationSheet) {
                            AlertDialog(
                                onDismissRequest = { showNotificationSheet = false },
                                title = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.Notifications, contentDescription = null)
                                        Text("System Notifications", fontWeight = FontWeight.Bold)
                                    }
                                },
                                text = {
                                    if (notifications.isEmpty()) {
                                        Text("No new notifications.", style = MaterialTheme.typography.bodyMedium)
                                    } else {
                                        LazyColumn(
                                            verticalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.height(260.dp)
                                        ) {
                                            items(notifications) { notif ->
                                                Surface(
                                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Column(modifier = Modifier.padding(10.dp)) {
                                                        Text(notif.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                                        Text(notif.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },
                                confirmButton = {
                                    TextButton(onClick = { showNotificationSheet = false }) { Text("Close") }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
